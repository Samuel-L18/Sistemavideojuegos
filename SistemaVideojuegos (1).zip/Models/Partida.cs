using System;
public class Partida {
    public int Id { get; set; }
    public int JugadorId { get; set; }
    public int VideojuegoId { get; set; }
    public DateTime Fecha { get; set; }
    public int Puntaje { get; set; }
}