public class Jugador : Persona {
    public string Nickname { get; set; }
    public int Nivel { get; set; }
}