public class Videojuego {
    public int Id { get; set; }
    public string Nombre { get; set; }
    public string Genero { get; set; }
    public double Precio { get; set; }
}