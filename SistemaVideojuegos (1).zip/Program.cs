using System;
using System.Collections.Generic;

class Program {
    static List<Jugador> jugadores = new();
    static List<Videojuego> videojuegos = new();
    static List<Partida> partidas = new();

    static void Main() {
        Console.WriteLine("Sistema Videojuegos");
    }
}
