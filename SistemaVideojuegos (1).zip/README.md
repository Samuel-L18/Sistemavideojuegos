# Sistema de Videojuegos

Aplicación de consola en C# para gestionar jugadores, videojuegos y partidas.

## Funcionalidades
- CRUD de Jugadores
- CRUD de Videojuegos
- CRUD de Partidas
- Persistencia en CSV usando CsvHelper

## UML
El diagrama se encuentra en el archivo `uml.mmd` (compatible con Draw.io o Mermaid).

## Requisitos
- .NET 6 o superior

## Instalación
```bash
dotnet restore
dotnet run
```

## Estructura
- Models/
- Services/
- Data/
- Program.cs

## Autor
Proyecto académico - Taller 1
